# weather-vanilla-js
Responsive weather app built with vanilla JS, CSS and HTML. Fetches real time data using a weather api and updates the DOM.
